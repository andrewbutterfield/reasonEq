{-# LANGUAGE PatternSynonyms #-}

module SAT (dpll
          , negateTerm
          , equivFree
          , implFree
          , nnf
          , cnf
          , getUnitClauses
          , applyUnitPropagation
          , simplifyFormula) where
    
import System.Environment
import System.IO
import System.FilePath
import System.Directory
import System.Exit
import Data.Map (Map)
import qualified Data.Map as M
import Data.Set (Set)
import qualified Data.Set as S
import Data.List
import Data.Maybe
import Data.Char

import NiceSymbols hiding (help)

import Utilities
import StratifiedDAG
import Persistence
import Files

import LexBase
import Variables
import AST
import VarData
import Binding
import SideCond
import Assertions
import REqState
import StdSignature(propSignature)
import UTPSignature
import Instantiate
import TestRendering
import TestParsing
import REPL
import Dev

import Debug.Trace

implFree :: Term -> Term
implFree x@(Val a b) = x
implFree x@(Var a b) = x
implFree (Cons a b (Identifier nm _) (p:[])) = Cons a b (jId nm) [(implFree p)]
implFree (Cons a b (Identifier nm _) (p:q:[])) 
                              | nm == "implies" = Cons a b (jId "lor") [Cons a b (jId "lnot") [(implFree p)],(implFree q)]
                              | otherwise = Cons a b (jId nm) [(implFree p),(implFree q)]

equivFree :: Term -> Term
equivFree x@(Val a b) = x
equivFree x@(Var a b) = x
equivFree t@(Cons a b (Identifier nm _) xs)
  | nm == "equiv" = equivFree (equivFreeNested t)
  | otherwise = Cons a b (jId nm) (map equivFree xs)

equivFreeNested :: Term -> Term
equivFreeNested (Cons a b (Identifier nm _) (p:q:[])) 
 = Cons a b (jId "land") [Cons a b (jId "implies") [(equivFree p), (equivFree q)], Cons a b (jId "implies") [(equivFree q), (equivFree p)]]
equivFreeNested (Cons a b (Identifier nm _) (p:q:rest)) 
 = equivFreeNested (Cons a b (jId nm) ([(Cons a b (jId "land") [Cons a b (jId "implies") [p, q], Cons a b (jId "implies") [q, equivFree p]])] ++ rest))
                          
nnf :: Term -> Term
nnf t@(Val a b) = t
nnf t@(Var a b) = t
nnf (Cons a1 b1 (Identifier nm1 _) ((Cons a2 b2 (Identifier nm2 _) (t:[])):[])) 
    | nm1 == "lnot" && nm2 == "lnot" =  nnf t
    | otherwise = Cons a1 b1 (jId nm1) [Cons a2 b2 (jId nm2) [(nnf t)]]
nnf (Cons a b (Identifier nm1 _) ((Cons a2 b2 (Identifier nm2 _) (p:q:[])):[]))  
    | nm1 == "lnot" && nm2 == "lor" = Cons a b (jId "land") [(nnf (negateTerm p)), (nnf (negateTerm q))]       
    | nm1 == "lnot" && nm2 == "land" = Cons a b (jId "lor") [(nnf (negateTerm p)), (nnf (negateTerm q))]    
    | otherwise = Cons a b (jId nm1) [Cons a2 b2 (jId nm2) [(nnf p),(nnf q)]]        
nnf (Cons a b (Identifier nm _) (p:q:[])) = Cons a b (jId nm) [(nnf p), (nnf q)]
nnf (Cons a b (Identifier nm _) (p:[]))
    | p == Val (termkind p) (Boolean True) = Val (termkind p) (Boolean False)
    | p == Val (termkind p) (Boolean False) = Val (termkind p) (Boolean True)
    | otherwise = Cons a b (jId nm) [(nnf p)]


negateTerm :: Term -> Term
negateTerm t = Cons (termkind t) True (jId "lnot") [t]

cnf :: Term -> Term
cnf (Cons a b (Identifier nm _) (p:q:[])) 
                                 | nm == "land" = Cons a b (jId nm) [(cnf p), (cnf q)]  
                                 | nm == "lor" = distr (cnf p) (cnf q)
cnf t = t

distr :: Term -> Term -> Term
distr (Cons a b (Identifier nm _) (p:q:[])) t
                                 | nm == "land" = Cons a b (jId "land") [(distr p t), (distr q t)]
distr t (Cons a b (Identifier nm _) (p:q:[]))
                                 | nm == "land" = Cons a b (jId "land") [(distr p t), (distr q t)]
distr t1 t2 = Cons (termkind t1) True (jId "lor") [t1,t2]

getUnitClauses :: Term -> [Term]
getUnitClauses t@(Var _ _) = [t]
getUnitClauses t@(Cons a b (Identifier nm _) (p:[]))
                                          | nm == "lnot" = [t]
                                          | otherwise = []
getUnitClauses t@(Cons a b (Identifier nm _) (p:q:[]))
                                          | nm == "land" = getUnitClauses p ++ getUnitClauses q
                                          | otherwise = []
getUnitClauses t = []

printArray :: [Term] -> String
printArray [] = ""
printArray (x:xs) = (trTerm 0 x) ++ ", " ++ (printArray xs)

getAllVariables :: Term -> [Term]
getAllVariables t@(Val _ _) = []
getAllVariables t@(Var _ _) = [t]
getAllVariables t@(Cons a b (Identifier nm _) (p:[])) = [t]
getAllVariables (Cons a b (Identifier nm _) (p:q:[])) = (getAllVariables p ++ getAllVariables q)

chooseUnassigned :: [a] -> Maybe a
chooseUnassigned [] = Nothing
chooseUnassigned (x:_) = Just x

applyUnassigned :: Term -> Term -> Term
applyUnassigned p@(Val _ _) _ = p
applyUnassigned p@(Var _ x) (Var tk k) | k == x = Val tk (Boolean True)
                                       | otherwise = p
applyUnassigned p@(Var tk y) (Cons a b (Identifier nm _) ((Var _ x):[]))
                                        | x == y = Val tk (Boolean False)
                                        | otherwise = p
applyUnassigned p@(Cons _ _ _ ((Var _ x):[])) (Var tk y)
                                        | x == y = Val tk (Boolean False)
                                        | otherwise = p
applyUnassigned p@(Cons _ _ _ ((Var _ x):[])) (Cons _ _ _ ((Var tk y):[])) 
                                        | x == y = Val tk (Boolean True)
                                        | otherwise = p                                  
applyUnassigned (Cons a b (Identifier nm _) (p:q:[])) t 
                                        = Cons a b (jId nm) [applyUnassigned p t, applyUnassigned q t]

simplifyFormula :: Term -> Term
simplifyFormula t@(Cons a b (Identifier "land" _) (p:q:[])) 
                          | ((simplifyFormula p) == (Val P (Boolean True))) && ((simplifyFormula q) == (Val P (Boolean True))) = Val P (Boolean True)
                          | ((simplifyFormula p) == (Val P (Boolean False))) || ((simplifyFormula q) == (Val P (Boolean False))) = Val P (Boolean False)
                          | simplifyFormula p == (Val P (Boolean True)) = simplifyFormula q
                          | simplifyFormula q == (Val P (Boolean True)) = simplifyFormula p
                          | otherwise = Cons a b (jId "land") [simplifyFormula p, simplifyFormula q]
simplifyFormula t@(Cons a b (Identifier "lor" _) (p:q:[])) 
                          | ((simplifyFormula p) == (Val P (Boolean True))) || ((simplifyFormula q) == (Val P (Boolean True))) = Val P (Boolean True)
                          | simplifyFormula p == (Val P (Boolean False)) = simplifyFormula q
                          | simplifyFormula q == (Val P (Boolean False)) = simplifyFormula p
                          | otherwise = Cons a b (jId "lor") [simplifyFormula p, simplifyFormula q]
simplifyFormula t = t

checkResult :: Term -> Bool
checkResult (Val _ x)
            | x == (Boolean True) = True
            | x == (Boolean False) = False 

applyUnitPropagation :: Term -> [Term] -> Term
applyUnitPropagation formula variables = foldl (\acc variable -> applyUnassigned acc variable) formula variables

showOperators :: Term -> String
showOperators (Val _ _) = ""
showOperators (Var _ _) = ""
showOperators (Cons _ _ (Identifier nm _) xs) = show nm ++ " " ++ (concatMap showOperators xs)

dpll :: Term -> Bool
dpll t = do let e = equivFree t
            let normalisedFormula = trace("equivFree: " ++ (trTerm 0 e) ++ " " ++ (showOperators e)) cnf $ nnf $ implFree $ equivFree e
            let f = trace ("cnf " ++ (trTerm 0 $ normalisedFormula)) simplifyFormula normalisedFormula
            let result = dpllAlg f        
            result

dpllAlg :: Term -> Bool
dpllAlg form = do let f = trace ("initial " ++ (trTerm 0 $ form)) simplifyFormula (applyUnitPropagation form (nub $ getUnitClauses form))
                  let arr = nub $ getAllVariables f
                  case trace ("unitProp " ++ (trTerm 0 f)) chooseUnassigned arr of
                    Nothing -> do let res = simplifyFormula f
                                  checkResult res
                    Just elem -> do let f1 = applyUnassigned f elem
                                    let f2 = trace ("assigned " ++ (trTerm 0 f1)) simplifyFormula f1
                                    case trace ("simplified " ++ (trTerm 0 f2)) dpllAlg f2 of
                                      True -> True
                                      False -> do let elem' = nnf (Cons (termkind elem) True (jId "lnot") [elem])
                                                  let f1' = applyUnassigned form elem'
                                                  let f2' = trace ("assigned " ++ (trTerm 0 f1')) simplifyFormula f1'
                                                  case trace ("simplified " ++ (trTerm 0 f2')) dpllAlg f2' of
                                                    True -> True
                                                    False -> False